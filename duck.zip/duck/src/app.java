import java.util.ArrayList;
import java.util.Scanner;
import  java.util.List;

public class app {
    private static List<Client> clients = new ArrayList();
    private static List<car> cars = new ArrayList();
    private static List<manager> managers = new ArrayList();
    private static List<admin> admins = new ArrayList();
    private static Scanner scr = new Scanner(System.in);
    private static int count = 0;



    static {
        Client Alina = new Client(10000000, "Alina", "Edemskaya");
        Client Dima = new Client(500500000, "Dima", "Gavrilovskiy");
        Client Liza = new Client(9000000, "Liza", "Brazhnikova");
        clients.add(Alina);
        clients.add(Dima);
        clients.add(Liza);
        car car1 = new car("BMW", 500000, "red", 2);
        car car2 = new car("kia", 80000000, "blue", 3);
        car car3 = new car("mazda", 70000000, "green", 4);
        car car4 = new car("BMW", 500000, "black", 1);
        cars.add(car1);
        cars.add(car2);
        cars.add(car3);
        cars.add(car4);
        manager manager = new manager("Sofa", "Kochanova", 123, 0001);
        manager manager2 = new manager("Nikita", "Ivanov", 321, 0002);
        managers.add(manager);
        managers.add(manager2);
        admin admin = new admin("admin", "admin admin");
        admins.add(admin);


    }

    static void startClient() {
        while (true) {
            System.out.println("Выберите доступное действие: ");
            System.out.println("1.Посмотреть доступные автомобили");
            System.out.println("2. Оформить заказ");
            System.out.println("3.Принять заказ");
            System.out.println("4.Выйти из программы");
            int choice = scr.nextInt();
            switch (choice){
                case 1:

                    }
                    break;
                case 2:
                    logIn();
                    break;
                case 3:
                    break;
                case 4:
                    break;
                default:
                    System.out.println("Некорректный выбор.Попробуйте снова.");



            }
    }

    private static void logIn() {
        System.out.println("Введите имя ");
        String name = scr.nextLine();

        for (var client : clients) {
            if (count < 2) {
                if (name.equals(client.getName())) {
                    System.out.println("Вы успешно вошли");
                    scr.close();
                    break;
                } else {
                    System.out.println("Попробуйте снова ");
                    count++;
                    logIn();
                }
                System.out.println("выход из программы");
                break;
            }
        }
        private static void auto() {
            for (int i= 0; i < cars.size();i++){
                System.out.println(cars.get(i).getModel()+ " "+(cars.get(i).getColor() +" ") + (cars.get(i).getCost()+ " "));
            }

        }


    }
}


