public class manager {
     String name;
     String surname;
     int pincode;
     int id;


    public manager(String name, String surname, int pincode, int id) {
        this.name = name;
        this.surname = surname;
        this.pincode = pincode;
        this.id = id;
    }
}
