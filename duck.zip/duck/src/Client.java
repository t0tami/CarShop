public class Client implements prosmotr_zakaza{
     int balance;
     String name;
     String surname;

    public Client(int balance, String name, String surname) {
        this.balance = balance;
        this.name = name;
        this.surname = surname;
    }

    public int getBalance() {
        return balance;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
}
