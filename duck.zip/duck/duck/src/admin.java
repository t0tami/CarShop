public class admin implements prosmotr_zakaza,ydalenie_zakaza {
     String login;
     String password;

    public admin(String login, String password) {
        this.login = login;
        this.password = password;
    }
}
