public interface ydalenie_zakaza {

}
