class Order {
    private String orderId;
    private Client client;


    public Order(String orderId, Client client) {
        this.orderId = orderId;
        this.client = client;

    }

    public String getOrderId() {
        return orderId;
    }

    public Client getClient() {
        return client;
    }

}
