import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import  java.util.List;

public class app {
    private static List<Client> clients = new ArrayList();
    private static List<car> cars = new ArrayList();
    private static List<manager> managers = new ArrayList();
    private static List<admin> admins = new ArrayList();
    private static List<Order> orders = new ArrayList();
    private static Scanner scr = new Scanner(System.in);

    private static int count = 0;


    static {
        Client Alina = new Client(10000000, "Alina", "Edemskaya");
        Client Dima = new Client(500500000, "Dima", "Gavrilovskiy");
        Client Liza = new Client(9000000, "Liza", "Brazhnikova");
        clients.add(Alina);
        clients.add(Dima);
        clients.add(Liza);
        car car1 = new car("BMW", 5000000, "red", 2);
        car car2 = new car("kia", 80000000, "blue", 3);
        car car3 = new car("mazda", 70000000, "green", 4);
        car car4 = new car("toyota", 100000, "black", 1);
        cars.add(car1);
        cars.add(car2);
        cars.add(car3);
        cars.add(car4);
        manager manager = new manager("Sofa", "Kochanova", 666, 1111);
        manager manager2 = new manager("Nikita", "Ivanov", 321, 2222);
        managers.add(manager);
        managers.add(manager2);
        admin admin = new admin("admin", "admin admin");
        admins.add(admin);
        Order Order = new Order("0001", clients.get(0));
        orders.add(Order);

    }

    static void startClient() {
        boolean running = true;
        while (running) {
            System.out.println("Выберите доступное действие: ");
            System.out.println("1.Посмотреть доступные автомобили");
            System.out.println("2. Оформить заказ");
            System.out.println("3.Принять заказ");
            System.out.println("4.Выйти из программы");
            String choice = scr.nextLine();
            switch (choice) {
                case "1":
                    auto();
                    break;
                case "2":
                    logIn();
                    break;
                case "3":
                    manager();
                    break;
                case "4":
                    System.out.println("Вы вышли из программы.Досвидания");
                    running = false;
                    break;
                default:
                    System.out.println("Некорректный выбор.Попробуйте снова.");
                    startClient();
            }

        }
    }

    private static void auto() {
        System.out.println("Доступные авто: ");
        for (int i = 0; i < cars.size(); i++) {
            System.out.println("модель: " + cars.get(i).getModel() + " Цвет: " + (cars.get(i).color) + " Цена: " + (cars.get(i).cost) + " Количество:  " + (cars.get(i).shtyk));
        }
    }

    private static void logIn() {
        if (count >= 3) {
            System.out.println("Превышено максимальное количество попыток входа. Выход из программы.");
            return;
        }

        System.out.println("Введите логин");
        String login = scr.nextLine();

        boolean userFound = false;

        for (var client : clients) {
            if (login.equals(client.getName())) {
                System.out.println("Вы успешно вошли");
                userFound = true;
                buyAuto();
                break;
            }
        }

        if (!userFound) {
            System.out.println("Такого пользователя не существует! 1 - Попробовать снова, 2 - Зарегистрироваться");
            String choice = scr.nextLine();
            scr.nextLine();
            switch (choice) {
                case "1":
                    count++;
                    logIn();
                    break;

                case "2":
                    System.out.print("Введите имя клиента: ");
                    String name = scr.nextLine();

                    System.out.print("Введите фамилию клиента: ");
                    String surname = scr.nextLine();
                    Random rand = new Random();
                    int balance = rand.nextInt(4700000) + 300000;

                    Client newClient = new Client(balance, name, surname);
                    clients.add(newClient);
                    System.out.println("Клиент добавлен с балансом: " + balance + " рублей!");
                    buyAuto();
                    break;

                default:
                    System.out.println("Некорректный выбор.");
                    break;
            }
        }
    }

    private static void buyAuto() {
        System.out.println("Выберите автомобиль (по индексу, начиная с 0):");
        auto();

        int carChoice = scr.nextInt();
        scr.nextLine();

        if (carChoice >= 0 && carChoice < cars.size()) {
            car selectedCar = cars.get(carChoice);
            if (selectedCar.getShtyk() > 0) {
                System.out.println("Вы выбрали: " + selectedCar.getModel() + ". Цена: " + selectedCar.getCost() + " рублей.");

                if (Client.getBalance() >= selectedCar.getCost()) {
                    System.out.println("Заказ оформлен успешно!");
                    Client.setBalance((int) (Client.getBalance() - selectedCar.getCost()));
                    selectedCar.setShtyk(selectedCar.getShtyk() - 1);
                    System.out.println("Новый баланс: " + Client.getBalance() + " рублей.");

                } else {
                    System.out.println("Недостаточно средств для оформления заказа.");
                    buyAuto();
                }
            } else {
                System.out.println("Некорректный выбор автомобиля.");
            }
        }
    }
        private static void manager() {
            if (count >= 3) {
                System.out.println("Превышено максимальное количество попыток входа. Выход из программы.");
                return;
            }

            System.out.println("Введите пинкод");
            int pin = scr.nextInt();

            boolean managerFound = false;

            for (var manager : managers) {
                if (pin == manager.getPincode()) {
                    System.out.println("Вы успешно вошли. Здравствуйте " + manager.getName() + " (ID: " + manager.getId() + ")");
                    managerFound = true;

                    break;
                }
            }

            if (!managerFound) {
                System.out.println("Такого пинкода не существует! ");
                count++;
                manager();
            }
        }
        private static void zakaz(){
            System.out.println("Доступные заказы: ");
        }
    }

















