import org.w3c.dom.ls.LSOutput;

public interface prosmotr_zakaza {
    default void bron_auto(){
        System.out.println("Автомобль забронирован ");
    }
    default void buy_auto(){
        System.out.println("Автомобль куплен");
    }


}
